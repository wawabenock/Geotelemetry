/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmlgenerator;

import java.util.Date;

/**
 *
 * @author kelvin
 */
public class Kmlgenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**
		 * Array that will contain the values
		 * px - x pixels
		 * py - y pixels
		 */        
		System.out.println("START: "+new Date());
                double R = 6371000;
		int px = 480, py = 800;
		double[][] values;
		values = new double[px][py];
		
		for (int ab = 0; ab < px; ab+=10) {
			for (int cd = 0; cd < py; cd+=10) {

				/**
				 * X Orientation value
				 */
				double x = 69.48;
                                x = Math.abs(x);
				double w = x;
				double d = 2.0625;
                                    d = Math.abs(d);
                                double h = 30;
                                 
				double fieldAngle = 53.78303864;
				double[] p = {-1.29861094, 36.7908756};

				/**
				 * Incase w is negative, consider the magnitude
				 */
				if(w < 0) {
					w = -1 * w;
				}

				/**
				 * AB Values
				 */
				double AB = (h*(1/Math.cos(w)*Math.sin(90+(fieldAngle/2)))* Math.tan(fieldAngle / 2)) / (Math.sin(90-w-(fieldAngle/2)));
				/**
				 * CD Values
				 */
				double CD = (h*(1/Math.cos(d)*Math.sin(90+(fieldAngle/2)))) / (Math.sin(90-d-(fieldAngle/2)));
				/**
				 * delta x
				 */
				double deltaX = h*Math.tan(w);
				/**
				 * delta Y
				 */
				double deltaY = h*Math.tan(d);
				/**
				 * Lambda X
				 */
				double lambdaX = AB / ab;

				/**
				 * Lambda Y
				 */
				double lambdaY = CD / cd;

				double X = deltaX + lambdaX * ab;
				double Y = deltaY + lambdaY * cd;
                                double X1 = ((X / R) * 180 / Math.PI);
                                double Y1 = ((X / R) * 180 / Math.PI);
                                
                                double X2 = X1 + p[0];
                                double Y2 = Y1 + p[1];
                                
				System.out.print("\t|"+ab+","+cd+"|={"+X2+","+Y2+"}");
			}
			System.out.println();
		}
		
		System.out.println("END: "+new Date());
    }
}
