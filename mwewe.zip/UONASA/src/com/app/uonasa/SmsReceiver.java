package com.app.uonasa;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

public class SmsReceiver extends BroadcastReceiver {
	public static final String PHONE = "712270408";
	public static final String START = "120";
	public static final String START_COMMAND = "START_COMMAND";
	public static final String STOP_COMMAND = "STOP_COMMAND";
	public static final String STOP = "130";
	public static final String START_ = "120";
	public static final String _COMMAND = "_COMMAND";
	public static enum COMMAND {START, STOP, FINISH};
	
	@Override
	public void onReceive(Context context, Intent intent) {

		Bundle extras = intent.getExtras();
		if (extras == null)
			return;

		Object[] pdus = (Object[]) extras.get("pdus");
		for (int i = 0; i < pdus.length; i++) {
			SmsMessage SMessage = SmsMessage.createFromPdu((byte[]) pdus[i]);
			String sender = SMessage.getOriginatingAddress();
			String body = SMessage.getMessageBody().toString();			
			
			if(body.equals(START)) {
				/**
				 * Start the camera app
				 */
				Intent ins = new Intent(context, CameraApp.class);
				ins.putExtra(START_COMMAND, START);
				ins.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(ins);
				
				// A custom Intent that will used as another Broadcast
				Intent in = new Intent("SmsMessage.intent.MAIN")
						.putExtra(_COMMAND, START);		
				context.sendBroadcast(in);
				
			}else if (body.equals(STOP)) {
				/**
				 * Just send the broadcast intent to the activity
				 */
				
				// A custom Intent that will used as another Broadcast
				Intent in = new Intent("SmsMessage.intent.MAIN")
						.putExtra(_COMMAND, STOP);		
				context.sendBroadcast(in);				
			}
		}
	}
}