package com.app.uonasa;

public class Utils {
	/**
	 * This is the time between subsequent take of photos
	 */
	public static int TIME_IN_SECONDS = 15;
	/**
	 * The log tag fot the application
	 */
	public static String TAG = "UONASA";
}
