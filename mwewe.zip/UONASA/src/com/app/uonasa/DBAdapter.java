package com.app.uonasa;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DBAdapter {

	public static final String MYDATABASE_NAME = "MWEWE_DB";
	public static final String IMAGES_TABLE = "IMAGES";
	public static final String PARAMETERS_TABLE = "PARAMETERS";
	public static final int MYDATABASE_VERSION = 1;
	public static final String KEY_ID = "_id";

	//create table MY_DATABASE (ID integer primary key, Content text not null);
	private static final String SCRIPT_CREATE_IMAGE = 
			"create table " + IMAGES_TABLE + " ("
					+ KEY_ID + " integer primary key autoincrement, "
					+ "name text not null, " +
					 "path text not null, " +
					"status text not null); ";

	private static final String SCRIPT_CREATE_PARAMETER = 
			"create table " + PARAMETERS_TABLE + " ("
					+ KEY_ID + " integer primary key autoincrement, "+
					"image text not null, " +
					"gps_latitude text not null, " +
					"gps_longitude text not null, " +
					"altitude text not null, " +
					"speed text not null, " +
					"ses_x text not null, " +
					"ses_y text not null, " +
					"ses_z text not null);";	
	
	private DBHelper sqLiteHelper;
	private SQLiteDatabase sqLiteDatabase;
	private Context context;

	public DBAdapter(Context c){
		context = c;
	}

	public DBAdapter openToRead() throws android.database.SQLException {
		sqLiteHelper = new DBHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);
		sqLiteDatabase = sqLiteHelper.getReadableDatabase();
		return this; 
	}

	public DBAdapter openToWrite() throws android.database.SQLException {
		sqLiteHelper = new DBHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);
		sqLiteDatabase = sqLiteHelper.getWritableDatabase();
		return this; 
	}

	public void close(){
		sqLiteHelper.close();
	}

	/**
	 * Insert image
	 * @param content
	 * @return
	 */
	public long insertImage(String name, String path){
		ContentValues contentValues = new ContentValues();
		contentValues.put("name", name);
		contentValues.put("path", path);
		contentValues.put("status", "0");
		return sqLiteDatabase.insert(IMAGES_TABLE, null, contentValues);
	}

	/**
	 * Update the given record to indicate that the image has been uploaded
	 * @param name The name of the photo in question
	 * @return the number of records updated
	 */
	public long setImageUploded(String name){
		ContentValues contentValues = new ContentValues();
		contentValues.put("status", 1);
		return sqLiteDatabase.update(IMAGES_TABLE, contentValues, "name=?", new String[]{name});
	}
	/**
	 * Delete image
	 * @return 1 if deleted, 0 otherwise
	 */
	public int deleteAllImage(){
		return sqLiteDatabase.delete(IMAGES_TABLE, null, null);
	}

	/**
	 * Queue all the images, but those that are pending
	 * @return
	 */
	public ArrayList<String[]> queueAllImageString(){
		ArrayList<String[]> data = new ArrayList<String[]>();
		String[] columns = new String[]{"name", "path"};
		Cursor cursor = sqLiteDatabase.query(IMAGES_TABLE, columns, 
				null, null, null, null, null);

		for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
			String[] row = {
				cursor.getString(cursor.getColumnIndex("name")), 
				cursor.getString(cursor.getColumnIndex("path"))};
			data.add(row);
		}		
		return data;
	}

	/**
	 * Insert image parameters
	 * @param <br />values An array containing the image parameters</br>
	 * 			<b>image, gps_latitude, gps_longitude, altitude, speed, ses_x, ses_y, ses_z</b>
	 * @return
	 */
	public long insertImageParameters(Object...values){		
		String image = null, gps_latitude = null, gps_longitude = null, 
				altitude = null, speed = null, ses_x = null, ses_y = null, ses_z = null;		 
		if (values.length > 0 && values[0] != null) image = values[0].toString();		 
		if (values.length > 1 && values[1] != null) gps_latitude= values[1].toString();		 
		if (values.length > 2 && values[2] != null) gps_longitude= values[2].toString();		 
		if (values.length > 3 && values[3] != null) altitude= values[3].toString();		 
		if (values.length > 4 && values[4] != null) speed= values[4].toString();		 
		if (values.length > 5 && values[5] != null) ses_x= values[5].toString();		 
		if (values.length > 6 && values[6] != null) ses_y= values[6].toString();	 
		if (values.length > 7 && values[7] != null) ses_z= values[7].toString();
		
		ContentValues contentValues = new ContentValues();
		contentValues.put("image", image);
		contentValues.put("gps_latitude", gps_latitude);
		contentValues.put("gps_longitude", gps_longitude);
		contentValues.put("altitude", altitude);
		contentValues.put("speed", speed);
		contentValues.put("ses_x", ses_x);
		contentValues.put("ses_y", ses_y);
		contentValues.put("ses_z", ses_z);
		
		if (ses_x != null && ses_y != null && ses_z != null)
			return sqLiteDatabase.insert(PARAMETERS_TABLE, KEY_ID, contentValues);
		else throw new NullPointerException("Sensor values for X, Y and Z cannot be null!");
	}

	/**
	 * Delete image Parameter
	 * @return 1 if deleted, 0 otherwise
	 */
	public int deleteAllImageParameters(){
		return sqLiteDatabase.delete(PARAMETERS_TABLE, null, null);
	}

	/**
	 * Queue all the images Parameters, but those that are pending
	 * @return ArrayList containing all the image parametes we need
	 */
	public ArrayList<String> queueImageParameterString(String image){
		ArrayList<String> data = new ArrayList<String>();
		String[] columns = new String[]{"gps_latitude", "gps_longitude", "altitude", "speed", "ses_x", 
				"ses_y", "ses_z"};
		Cursor cursor = sqLiteDatabase.query(PARAMETERS_TABLE, columns, 
				"image=?", new String[]{image}, null, null, null);
		
		for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
			/**
			 * Add all the data
			 */
			data.add(cursor.getString(cursor.getColumnIndex("gps_latitude")));
			data.add(cursor.getString(cursor.getColumnIndex("gps_longitude")));
			data.add(cursor.getString(cursor.getColumnIndex("altitude")));
			data.add(cursor.getString(cursor.getColumnIndex("speed")));
			data.add(cursor.getString(cursor.getColumnIndex("ses_x")));
			data.add(cursor.getString(cursor.getColumnIndex("ses_y")));
			data.add(cursor.getString(cursor.getColumnIndex("ses_z")));
			break;
		}
		return data;
	}
	
	/**
	 * Helper class to encapsulate all th insert, update and delete functions of the database
	 */
	class DBHelper extends SQLiteOpenHelper {

		public DBHelper(Context context, String name, CursorFactory factory, int version) {
			super(context, name, factory, version);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(SCRIPT_CREATE_IMAGE);
			db.execSQL(SCRIPT_CREATE_PARAMETER);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS "+IMAGES_TABLE);
			db.execSQL("DROP TABLE IF EXISTS "+PARAMETERS_TABLE);
			onCreate(db);
		}

	}
}
