package com.app.uonasa;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.Toast;
/**
 * The Main Activity.
 *	
 */
public class MCamera extends Activity implements LocationListener{
	private static final String TIMESTAMP = "TIMESTAMP";
	private static final String LOCLATITUDE = "LOCLATITUDE";
	private static final String LOCACCURACY = "LOCACCURACY";
	private static final String LOCTIME = "LOCTIME";
	private static final String LOCALTITUDE = "LOCALTITUDE";
	private static final String LOCBEARING = "LOCBEARING";
	private static final String LOCSPEED = "LOCSPEED";
	private static final String LOCLONGITUDE = "LOCLONGITUDE";

	private Camera c = null;
	private boolean mhasCamera;
	private CameraPreview mPreview;
	private Timer timer = new Timer();
	private static int COUNTER = 0;
	private LocationManager locaManager;
	private FrameLayout preview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.camera_layout);
		/**
		 * 
		 */
		mhasCamera = checkCameraHardware(getBaseContext());
		c = getCameraInstance();
		cameraInfo();

		//setCameraDisplayOrientation(this, 0, c);
		// Create our Preview view and set it as the content of our activity.		
		preview = (FrameLayout) findViewById(R.id.camera_preview);
		mPreview = new CameraPreview(this, c);
		preview.addView(mPreview);

		/**
		 * on click method on the mPreview
		 */
		mPreview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				takePhoto(v);
			}
		});
		/**
		 * Set the schedule function and rate / delay
		 */
		COUNTER = 0;
		//timer.scheduleAtFixedRate(new CameraTask(), 2*1000, Utils.TIME_IN_SECONDS*1000);

		/**
		 * Location Updates
		 */
		locaManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		locaManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
		locaManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
	}

	/**
	 * Take photo button
	 */
	public void takePhoto(View v) {
		try {
			c.takePicture(null, null,
					new PhotoHandler(getApplicationContext()));
		}catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	protected void onPause() {
		if (c != null) {
			c.release();
			c = null;
		}
		if (timer != null) {
			timer.cancel();
		}
		super.onPause();
	}

	public static void setCameraDisplayOrientation(Activity activity,
			int cameraId, android.hardware.Camera camera) {
		android.hardware.Camera.CameraInfo info =
				new android.hardware.Camera.CameraInfo();
		android.hardware.Camera.getCameraInfo(cameraId, info);
		int rotation = activity.getWindowManager().getDefaultDisplay()
				.getRotation();
		int degrees = 0;
		switch (rotation) {
		case Surface.ROTATION_0: degrees = 0; break;
		case Surface.ROTATION_90: degrees = 90; break;
		case Surface.ROTATION_180: degrees = 180; break;
		case Surface.ROTATION_270: degrees = 270; break;
		}

		int result;
		if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
			result = (info.orientation + degrees) % 360;
			result = (360 - result) % 360;  // compensate the mirror
		} else {  // back-facing
			result = (info.orientation - degrees + 360) % 360;
		}
		camera.setDisplayOrientation(result);
	}

	/** Check if this device has a camera */
	private boolean checkCameraHardware(Context context) {
		if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
			// this device has a camera
			return true;
		} else {
			// no camera on this device
			Toast.makeText(this, "No camera on this device", Toast.LENGTH_LONG)
			.show();
			return false;
		}
	}

	/** A safe way to get an instance of the Camera object. */
	public static Camera getCameraInstance(){
		Camera c = null;
		try {
			c = Camera.open(); // attempt to get a Camera instance
		}
		catch (Exception e){
			// Camera is not available (in use or does not exist)
		}
		return c; // returns null if camera is unavailable
	}

	public void cameraInfo() {
		try {
			Camera.Parameters par = c.getParameters();
			par.setJpegQuality(100);
			par.setPictureFormat(ImageFormat.JPEG);
			/**
			 * Get a lcoation attribute
			 */
			try {
				Location location = locaManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
				if (location != null)
					par.set(TIMESTAMP, new Date().toString());
				par.set(LOCLATITUDE, location.getLatitude()+"");
				par.set(LOCLONGITUDE, location.getLongitude()+""); 
				par.set(LOCALTITUDE, location.getAltitude()+"");
				par.set(LOCACCURACY, location.getAccuracy()+"");
				par.set(LOCBEARING, location.getBearing()+"");
				par.set(LOCSPEED, location.getSpeed()+"");
				par.set(LOCTIME, location.getTime()+"");
				/**
				 * Set parameters in the jpeg
				 */
				par.setGpsAltitude(location.getAltitude());
				par.setGpsLatitude(location.getLatitude());
				par.setGpsLongitude(location.getLongitude());
				par.setGpsTimestamp(location.getTime());
			}catch (Exception ex) {
				ex.printStackTrace();
			}
			/**
			 * Set focus
			 */
			par.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
			c.setParameters(par);
		}catch (Exception ex){
			ex.printStackTrace();
		}
	}

	/**
	 * Create the following PhotoHandler class which will be responsible for saving the photo the SD card
	 * @author kelvin
	 *
	 */
	class PhotoHandler implements PictureCallback {
		private final Context context;
		public PhotoHandler(Context context) {
			this.context = context;
		}

		@Override
		public void onPictureTaken(byte[] data, Camera camera) {
			File pictureFileDir = getDir();
			if (!pictureFileDir.exists() && !pictureFileDir.mkdirs()) {
				Log.d(Utils.TAG, "Can't create directory to save image.");
				Toast.makeText(context, "Can't create directory to save image.",
						Toast.LENGTH_LONG).show();
				return;
			}

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
			String date = dateFormat.format(new Date());
			String photoFile = "" + date + ".jpg";
			String filename = pictureFileDir.getPath() + File.separator + photoFile;
			File pictureFile = new File(filename);
			try {
				FileOutputStream fos = new FileOutputStream(pictureFile);
				if (data != null) fos.write(data);
				fos.close();
				Toast.makeText(context, "New Image saved:" + photoFile, Toast.LENGTH_LONG).show();
			} catch (Exception error) {
				Log.d(Utils.TAG, "File" + filename + "not saved: " + error.getMessage(), error);
				Toast.makeText(context, "Image could not be saved.", Toast.LENGTH_LONG).show();
			}
		}

		private File getDir() {
			File sdDir = Environment
					.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
			return new File(sdDir, "MCamera");
		}
	}

	/** A basic Camera preview class */
	public class CameraPreview extends SurfaceView implements SurfaceHolder.Callback {
		private SurfaceHolder mHolder;
		private Camera mCamera;
		public CameraPreview(Context context, Camera camera) {
			super(context);
			mCamera = camera;

			// Install a SurfaceHolder.Callback so we get notified when the
			// underlying surface is created and destroyed.
			mHolder = getHolder();
			mHolder.addCallback(this);

			// deprecated setting, but required on Android versions prior to 3.0
			mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		}
		public void surfaceCreated(SurfaceHolder holder) {
			// The Surface has been created, now tell the camera where to draw the preview.
			try {
				mCamera.setPreviewDisplay(holder);
				mCamera.startPreview();
			} catch (IOException e) {
				Log.d(Utils.TAG, "Error setting camera preview: " + e.getMessage());
			}
		}
		public void surfaceDestroyed(SurfaceHolder holder) {
			// empty. Take care of releasing the Camera preview in your activity.
		}
		public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
			// If your preview can change or rotate, take care of those events here.
			// Make sure to stop the preview before resizing or reformatting it.
			if (mHolder.getSurface() == null){
				// preview surface does not exist
				return;
			}
			// stop preview before making changes
			try {
				mCamera.stopPreview();
			} catch (Exception e){
				// ignore: tried to stop a non-existent preview
			}
			// set preview size and make any resize, rotate or
			// reformatting changes here
			// start preview with new settings
			try {
				mCamera.setPreviewDisplay(mHolder);
				mCamera.startPreview();
			} catch (Exception e){
				Log.d(Utils.TAG, "Error starting camera preview: " + e.getMessage());
			}
		}
	}

	/**
	 * A timer task run to take photos after the defined period of time.
	 * @author kelvin
	 *
	 */
	class CameraTask extends TimerTask {

		@Override
		public void run() {
			/**
			 * Called each time after the delay passed to the timer
			 */
			//COUNTER++;
			/**
			 * Release the camera and get it afresh after 2 photos
			 */
			if (COUNTER %2==0) {
				c.release();
				c = getCameraInstance();
				cameraInfo();
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						mPreview = new CameraPreview(getBaseContext(), c);
						preview.addView(mPreview);
					}
				});
			}
			takePhoto(null);
			Log.i(Utils.TAG, "photo taken");
		}		
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub

	}
}
