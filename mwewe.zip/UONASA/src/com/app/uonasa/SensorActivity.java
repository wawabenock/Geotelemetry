package com.app.uonasa;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 	To sum things up, to access sensor data you have to do the following things:
	Check sensor availability.
	Register a listener to a sensorManager.
	Catch the needed data , from onSensorChanged.
	Unregister the sensorManager's listener.
 * @author kelvin
 *
 */
public class SensorActivity extends Activity  implements SensorEventListener{

	//for accelerometer values
	TextView outputX;
	TextView outputY;
	TextView outputZ;

	//for orientation values
	TextView outputX2;
	TextView outputY2;
	TextView outputZ2, locationText;

	SensorManager sensorManager = null;
	private LocationManager locManager;
	private Location _location;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		setContentView(R.layout.sensor);

		//just some textviews, for data output
		outputX = (TextView) findViewById(R.id.TextView1);
		outputY = (TextView) findViewById(R.id.TextView2);
		outputZ = (TextView) findViewById(R.id.TextView3);

		outputX2 = (TextView) findViewById(R.id.TextView4);
		outputY2 = (TextView) findViewById(R.id.TextView5);
		outputZ2 = (TextView) findViewById(R.id.TextView6);
		locationText = (TextView) findViewById(R.id.location_str);

		/**
		 * There are 4 sensor delay settings: fastest, game, normal, and ui.
		 */
		locManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationLister);
		locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationLister);
		
		/**
		 * See which sensors are available
		 */
		List<Sensor> sensorList = 
				sensorManager.getSensorList(Sensor.TYPE_ORIENTATION); 
				if (sensorList.size() > 0) { 
					for (Sensor sensor : sensorList) {
						Log.i("SENSORS: ", sensor.getName() + ", " + sensor.getType());
					}
				}
	}

	/**
	 * Location listener
	 */
	private LocationListener locationLister = new LocationListener() {

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onProviderDisabled(String provider) {
		}

		@Override
		public void onLocationChanged(Location location) {
			//Log.i(Utils.TAG, location.getLatitude() + "->Location");
			_location = isBetterLocation(location, _location);
			
		}
	};
	private float azimuth;
	private float pitch;
	private float roll;

	@Override
	public void onAccuracyChanged(Sensor sen, int value) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onResume() {
		super.onResume();
		sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), sensorManager.SENSOR_DELAY_GAME);
		sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), sensorManager.SENSOR_DELAY_GAME);
	}

	@Override
	protected void onStop() {
		super.onStop();
		sensorManager.unregisterListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
		sensorManager.unregisterListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION));
	}

	public void onSensorChanged(SensorEvent event) {
		Location _location_ = locManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		//_location_ = isBetterLocation(_location_, _location);
		if (_location_ != null) {
			//Log.i(Utils.TAG, "Location: "+_location_.getLatitude());
			String locStr = "location:> " +
					"lat :"+_location_.getLatitude()+", " +
					"long:"+_location_.getLongitude()+", " +
					"acc :"+_location_.getAccuracy()+", " +
					"alt :"+_location_.getAltitude()+", " +
					"speed:"+_location_.getSpeed();
			locationText.setText(locStr);
		}else {
			_location_ = locManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			if (_location_ != null) {
				//Log.i(Utils.TAG, "Location: "+_location_.getLatitude());
				String locStr = "location:> " +
						"lat :"+_location_.getLatitude()+", " +
						"long:"+_location_.getLongitude()+", " +
						"acc :"+_location_.getAccuracy()+", " +
						"alt :"+_location_.getAltitude()+", " +
						"speed:"+_location_.getSpeed();
				locationText.setText(locStr);
			}
		}

		synchronized (this) {
			float[] mMagneticValues = null;		      
			float[] mAccelerometerValues = null;
			
			float mAzimuth;
			float mPitch;
			float mRoll;
			
			float[] gravity = {(float) 9.81, (float) 9.81, (float) 9.81};
			float[] linear_acceleration = null;
			
			switch (event.sensor.getType()){

			case Sensor.TYPE_ACCELEROMETER:
				String x, y, z;				
				x = "x:"+Float.toString(event.values[0]);
				y = "y:"+Float.toString(event.values[1]);
				z = "z:"+Float.toString(event.values[2]);				
				mAccelerometerValues = event.values.clone();
				
				outputX.setText(x);
				outputY.setText(y);
				outputZ.setText(z);
				break;

			case Sensor.TYPE_ORIENTATION:
				outputX2.setText("x:"+Float.toString(event.values[1]));
				outputY2.setText("y:"+Float.toString(event.values[2]));
				outputZ2.setText("z:"+Float.toString(event.values[0]));

				break;

			case Sensor.TYPE_MAGNETIC_FIELD:
				mMagneticValues = event.values.clone();
				Log.i("Magnetic field", "sfhjashdfjkhdfjhas");
				break;

			case Sensor.TYPE_GYROSCOPE:
				/**
				 * Measures All values are in radians/second and measure the rate of rotation 
				 * around the device's local X, Y and Z axis. The coordinate system is the same as is 
				 * used for the acceleration sensor. Rotation is positive in the counter-clockwise direction. 
				 * 
				 * That is, an observer looking from some positive location on the x, y or z axis at a device 
				 * positioned on the origin would report positive rotation if the device appeared to be rotating 
				 * counter clockwise
				 * values[0]: Angular speed around the x-axis  values[1]: 
				 * Angular speed around the y-axis  values[2]: 
				 * Angular speed around the z-axis 
				 */

				break;
			case Sensor.TYPE_PRESSURE:
				/**
				 * values[0]: Atmospheric pressure in hPa (millibar) 
				 */
				float pressure = event.values[0];
				Log.i(Utils.TAG, "pressure: "+pressure);
				/**
				 * Get the altitude between the ground and the level of the phone
				 */
				float altitude_difference = SensorManager.getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, 
						pressure);
				Log.i("ALTITUDE: ", altitude_difference+"");
						 /*- getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, 
								pressure_at_point1);*/
				break;
			}
			
			getOrientaion(mAccelerometerValues, mMagneticValues);
			
			if (mMagneticValues != null && mAccelerometerValues != null)
		    {
		        float[] R = new float[16];
		        SensorManager.getRotationMatrix(R, null, mAccelerometerValues, mMagneticValues);
		        float[] orientation = new float[3];
		        SensorManager.getOrientation(R, orientation);

		        orientation[0] = (float) Math.toDegrees(orientation[0]);
		        orientation[1] = (float) Math.toDegrees(orientation[1]);
		        orientation[2] = (float) Math.toDegrees(orientation[2]);

		        if (orientation[0] >= 360) orientation[0] -= 360;
		        if (orientation[0] < 0) orientation[0] = 360 - orientation[0];
		        if (orientation[1] >= 360) orientation[1] -= 360;
		        if (orientation[1] < 0) orientation[1] = 360 - orientation[1];
		        if (orientation[2] >= 360) orientation[2] -= 360;
		        if (orientation[2] < 0) orientation[2] = 360 - orientation[2];

		        azimuth = orientation[0];
		        pitch = orientation[1];
		        roll = orientation[2];		        
		        
		        Toast.makeText(getBaseContext(), azimuth+", "+pitch+", "+roll, 0).show();
		        Log.i("ORIRNTATION:", azimuth+", "+pitch+", "+roll);
		    }
			
			/**
			 * Process the data
			 */
			if (mMagneticValues != null && mAccelerometerValues != null) {
		        float[] R = new float[16];
		        SensorManager.getRotationMatrix(R, null, mAccelerometerValues, mMagneticValues);
		        float[] orientation = new float[3];
		        SensorManager.getOrientation(R, orientation);
		        
		        mAzimuth = orientation[0];
		        mPitch = orientation[1];
		        mRoll = orientation[2];
		        
		        Toast.makeText(getBaseContext(), mAzimuth+", "+mPitch+", "+mRoll, 0).show();
		        Log.i("ORIRNTATION:", mAzimuth+", "+mPitch+", "+mRoll);
		      }
		}		
	}

	public void getOrientaion(float[] aValues, float[] mValues) {
		float[] R = new float[16];
        float[] orientationValues = new float[3];

        if( aValues == null || mValues == null )
            return;

        if( !SensorManager.getRotationMatrix (R, null, aValues, mValues) )
            return;

        float[] outR = new float[16];
        SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_Z, SensorManager.AXIS_MINUS_X, outR);

        SensorManager.getOrientation (outR, orientationValues);

        orientationValues[0] = (float)Math.toDegrees (orientationValues[0]);
        orientationValues[1] = (float)Math.toDegrees (orientationValues[1]); 
        orientationValues[2] = (float)Math.toDegrees (orientationValues[2]);
        
        Log.i("LORIENTATION: ", orientationValues[0]+", "+orientationValues[1]+", "+orientationValues[2]);
	}
	
	private float filterAngle;
	private float dt=(float) 0.02;

	private float previousAngle;

	float comp_filter(float newAngle, float newRate) {

		float filterTerm0;
		float filterTerm1;
		float filterTerm2 = 0;
		float timeConstant;

		timeConstant=(float) 0.5; // default 1.0

		filterTerm0 = (newAngle - filterAngle) * timeConstant * timeConstant;
		filterTerm2 += filterTerm0 * dt;
		filterTerm1 = filterTerm2 + ((newAngle - filterAngle) * 2 * timeConstant) + newRate;
		filterAngle = (filterTerm1 * dt) + filterAngle;

		return previousAngle; // This is actually the current angle, but is stored for the next iteration
	}

	private static final int TWO_MINUTES = 1000 * 60 * 2;

	/** Determines whether one Location reading is better than the current Location fix
	 * @param location  The new Location that you want to evaluate
	 * @param currentBestLocation  The current Location fix, to which you want to compare the new one
	 */
	protected Location isBetterLocation(Location location, Location currentBestLocation) {
		if (currentBestLocation == null) {
			// A new location is always better than no location
			return currentBestLocation;
		}

		// Check whether the new location fix is newer or older
		long timeDelta = location.getTime() - currentBestLocation.getTime();
		boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
		boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
		boolean isNewer = timeDelta > 0;

		// If it's been more than two minutes since the current location, use the new location
		// because the user has likely moved
		if (isSignificantlyNewer) {
			return currentBestLocation;
			// If the new location is more than two minutes older, it must be worse
		} else if (isSignificantlyOlder) {
			return location;
		}

		// Check whether the new location fix is more or less accurate
		int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
		boolean isLessAccurate = accuracyDelta > 0;
		boolean isMoreAccurate = accuracyDelta < 0;
		boolean isSignificantlyLessAccurate = accuracyDelta > 200;

		// Check if the old and new location are from the same provider
		boolean isFromSameProvider = isSameProvider(location.getProvider(),
				currentBestLocation.getProvider());

		// Determine location quality using a combination of timeliness and accuracy
		if (isMoreAccurate) {
			return currentBestLocation;
		} else if (isNewer && !isLessAccurate) {
			return currentBestLocation;
		} else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
			return currentBestLocation;
		}
		return location;
	}

	/** Checks whether two providers are the same */
	private boolean isSameProvider(String provider1, String provider2) {
		if (provider1 == null) {
			return provider2 == null;
		}
		return provider1.equals(provider2);
	}

}
