package com.app.uonasa;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CameraApp extends Activity implements SurfaceHolder.Callback,
SensorEventListener {
	private static final String TAG = "Mwewe ";
	private static final String IMAGE_FOLDER = "/Mwewe/";
	private static final String EXTENTION = ".jpg";
	private String pictureName = "";
	public String picNameToshare = "";
	static final int FOTO_MODE = 0;
	private String imageFilePath;
	public static String imageFilePath1;
	boolean previewing = false;

	private Handler mHandler = new Handler();
	private FileOutputStream fos = null;
	public Bitmap framebmpScaled;
	public Bitmap SelecedFrmae;
	public static Bitmap mergeBitmap;
	public static Bitmap bmpfULL;
	private Camera camera;

	private SensorManager sensorManager = null;
	private Location _location;
	private Timer timer = new Timer();
	private LocationManager locManager;
	private Handler myHandler = new Handler();
	private SurfaceView surfaceView;
	private SurfaceHolder surfaceHolder;
	
	private int COUNTER = 0;
	private Button button;
	private TextView text;
	private String[] OUT1 = new String[3];
	private String[] OUT2 = new String[3];
	private float filterAngle;
	private float dt = (float) 0.02;
	private float previousAngle;
	private static final int TWO_MINUTES = 1000 * 60 * 2;
	private boolean isRunning = false;

	private static final Random random = new Random();

	/**
	 * The url for the server
	 */
	public static final String SERVER_URL = "http://eschoollink.com/mwewe";
	public static final String SERVER_URL_IMAGES = "http://eschoollink.com/mwewe/pics/"; 

	private BroadcastReceiver receiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			Bundle extras = intent.getExtras();
			if (extras == null)
				return;
			if (extras.containsKey(SmsReceiver._COMMAND)) {
				String comm = extras.getString(SmsReceiver._COMMAND);
				if (comm.equals(SmsReceiver.START)) {
					CameraControl(100);
					Toast.makeText(
							getBaseContext(),
							"UONASA has started taking pictures at the interval: "
									+ Utils.TIME_IN_SECONDS + " Seconds", 0)
									.show();
				} else if (comm.equals(SmsReceiver.STOP)) {
					CameraControl(110);
					Toast.makeText(
							getBaseContext(),
							"UONASA is stopping the camera... "
									+ Utils.TIME_IN_SECONDS
									+ " Seconds, Upload of files will start immediately!",
									0).show();
				}
			}
		}
	};
	private DBAdapter dhelper;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		setContentView(R.layout.camera);

		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		getWindow().setFormat(PixelFormat.UNKNOWN);
		button = (Button) findViewById(R.id.button);
		button.setOnClickListener(buttonListener);
		surfaceView = (SurfaceView) findViewById(R.id.camerapreview);
		surfaceHolder = surfaceView.getHolder();

		surfaceHolder.addCallback(this);
		surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		/**
		 * Set the schedule function and rate / delay
		 */
		COUNTER = 0;
		text = (TextView) findViewById(R.id.overlay_txt);

		/**
		 * Start and register the broadcast receiver
		 */
		IntentFilter filter = new IntentFilter("SmsMessage.intent.MAIN");
		registerReceiver(receiver, filter);
		
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_FASTEST);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_FASTEST);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE),
				SensorManager.SENSOR_DELAY_FASTEST);
		/*sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY),
				SensorManager.SENSOR_DELAY_FASTEST);*/

		/**
		 * There are 4 sensor delay settings: fastest, game, normal, and ui.
		 */
		locManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationLister);
		locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationLister);
		
		/**
		 * Deal with start command
		 */
		if(getIntent().getExtras() != null && getIntent().getExtras().containsKey(SmsReceiver.START_COMMAND)) {
			/**
			 * Start it straight away
			 */
			CameraControl(100);
			Toast.makeText(
					getBaseContext(),
					"UONASA has started taking pictures at the interval: "
							+ Utils.TIME_IN_SECONDS + " Seconds", 0)
							.show();
		}

		/**
		 * Create a database helper class instance
		 */
		dhelper = new DBAdapter(this);
		dhelper.openToWrite();
	}

	public void genKml() {
		System.out.println("START: "+new Date());
        double R = 6371000;
int px = 480, py = 800;
double[][] values;
values = new double[px][py];

for (int ab = 0; ab < px; ab+=10) {
	for (int cd = 0; cd < py; cd+=10) {

		/**
		 * X Orientation value
		 */
		double x = 69.48;
                        x = Math.abs(x);
		double w = x;
		double d = 2.0625;
                            d = Math.abs(d);
                        double h = 30;
                         
		double fieldAngle = 53.78303864;
		double[] p = {-1.29861094, 36.7908756};

		/**
		 * Incase w is negative, consider the magnitude
		 */
		if(w < 0) {
			w = -1 * w;
		}

		/**
		 * AB Values
		 */
		double AB = (h*(1/Math.cos(w)*Math.sin(90+(fieldAngle/2)))) / (Math.sin(90-w-(fieldAngle/2)));
		/**
		 * CD Values
		 */
		double CD = (h*(1/Math.cos(d)*Math.sin(90+(fieldAngle/2)))) / (Math.sin(90-d-(fieldAngle/2)));
		/**
		 * delta x
		 */
		double deltaX = h*Math.tan(w);
		/**
		 * delta Y
		 */
		double deltaY = h*Math.tan(d);
		/**
		 * Lambda X
		 */
		double lambdaX = AB / ab;

		/**
		 * Lambda Y
		 */
		double lambdaY = CD / cd;

		double X = deltaX + lambdaX * ab;
		double Y = deltaY + lambdaY * cd;
                        double X1 = ((X / R) * 180 / Math.PI);
                        double Y1 = ((X / R) * 180 / Math.PI);
                        
                        double X2 = X1 + p[0];
                        double Y2 = Y1 + p[1];
                        
		System.out.print("\t|"+ab+","+cd+"|={"+X2+","+Y2+"}");
	}
	System.out.println();
}

System.out.println("END: "+new Date());
	}
	
	private void newImage(String name, String path) {
		dhelper.insertImage(name, path);
	}

	/**
	 * Location listener
	 */
	private LocationListener locationLister = new LocationListener() {

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onProviderDisabled(String provider) {
		}

		@Override
		public void onLocationChanged(Location location) {
			_location = isBetterLocation(location, _location);
		}
	};

	@Override
	public void onAccuracyChanged(Sensor sen, int value) {
		// TODO Auto-generated method stub

	}

	private OnClickListener buttonListener = new OnClickListener() {
		public void onClick(View v) {
			if (!isRunning) {
				CameraControl(100);
				Toast.makeText(
						getBaseContext(),
						"UONASA has started taking pictures at the interval: "
								+ Utils.TIME_IN_SECONDS + " Seconds", 0).show();
			} else {
				CameraControl(110);
				Toast.makeText(
						getBaseContext(),
						"UONASA is stopping the camera... "
								+ Utils.TIME_IN_SECONDS + " Seconds", 0).show();
			}
		}
	};
	private float[] mAccelerometerValues;
	private float[] mMagneticValues;
	private float azimuth;
	private float pitch;
	private float roll;

	private void Resume() {
		getWindow().setFormat(PixelFormat.UNKNOWN);

		surfaceHolder = surfaceView.getHolder();
		surfaceHolder.addCallback(this);
		surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

		/**
		 * Set the holder
		 */
		try {
			camera = Camera.open();
			camera.setDisplayOrientation(90);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		if (previewing) {
			camera.stopPreview();
			previewing = false;
		}

		if (camera != null) {
			try {
				camera.setPreviewDisplay(surfaceHolder);
				camera.startPreview();
				previewing = true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_FASTEST);
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_FASTEST);

		/**
		 * There are 4 sensor delay settings: fastest, game, normal, and ui.
		 */
		locManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationLister);
		locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationLister);

	}

	@Override
	protected void onStop() {
		super.onStop();
		sensorManager.unregisterListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
		sensorManager.unregisterListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION));
	}

	private Location onGetLocation() {
		Location loc = locManager
				.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		if (loc != null) {
			return loc;
		} else {
			loc = locManager
					.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			if (loc != null) {
				return loc;
			}
		}
		return _location;
	}

	public void onSensorChanged(SensorEvent event) {
		/**
		 * Get the current location
		 */	
		onGetLocation();

		synchronized (this) {
			switch (event.sensor.getType()) {
			case Sensor.TYPE_ACCELEROMETER:
				String x,
				y,
				z;
				x = Float.toString(event.values[0]);
				y = Float.toString(event.values[1]);
				z = Float.toString(event.values[2]);		
				mAccelerometerValues = event.values.clone();

				OUT1[0] = (x);
				OUT1[1] = (y);
				OUT1[2] = (z);
				break;

			case Sensor.TYPE_ORIENTATION:
				OUT2[0] = (Float.toString(event.values[1]));
				OUT2[1] = (Float.toString(event.values[2]));
				OUT2[2] = (Float.toString(event.values[0]));
				break;

			case Sensor.TYPE_MAGNETIC_FIELD:
				mMagneticValues = event.values.clone();
				Log.i("Magnetic field", "sfhjashdfjkhdfjhas");
				break;

			case Sensor.TYPE_GYROSCOPE:
				
				break;
			case Sensor.TYPE_PRESSURE:
				/**
				 * values[0]: Atmospheric pressure in hPa (millibar)
				 */
				float pressure = event.values[0];
				Log.i(Utils.TAG, "pressure: " + pressure);
				break;
			}
			
			getOrientaion(mAccelerometerValues, mMagneticValues);
			
			if (mMagneticValues != null && mAccelerometerValues != null)
		    {
		        float[] R = new float[16];
		        SensorManager.getRotationMatrix(R, null, mAccelerometerValues, mMagneticValues);
		        float[] orientation = new float[3];
		        SensorManager.getOrientation(R, orientation);

		        orientation[0] = (float) Math.toDegrees(orientation[0]);
		        orientation[1] = (float) Math.toDegrees(orientation[1]);
		        orientation[2] = (float) Math.toDegrees(orientation[2]);

		        if (orientation[0] >= 360) orientation[0] -= 360;
		        if (orientation[0] < 0) orientation[0] = 360 - orientation[0];
		        if (orientation[1] >= 360) orientation[1] -= 360;
		        if (orientation[1] < 0) orientation[1] = 360 - orientation[1];
		        if (orientation[2] >= 360) orientation[2] -= 360;
		        if (orientation[2] < 0) orientation[2] = 360 - orientation[2];

		        azimuth = orientation[0];
		        pitch = orientation[1];
		        roll = orientation[2];		        
		        
		        Toast.makeText(getBaseContext(), azimuth+", "+pitch+", "+roll, 0).show();
		        Log.i("ORIRNTATION:", azimuth+", "+pitch+", "+roll);
		    }
			
			/**
			 * Process the data
			 */
			if (mMagneticValues != null && mAccelerometerValues != null) {
		        float[] R = new float[16];
		        SensorManager.getRotationMatrix(R, null, mAccelerometerValues, mMagneticValues);
		        float[] orientation = new float[3];
		        SensorManager.getOrientation(R, orientation);
		        
		        azimuth = orientation[0];
		        pitch = orientation[1];
		        roll = orientation[2];
		        
		        Toast.makeText(getBaseContext(), azimuth+", "+pitch+", "+roll, 0).show();
		        Log.i("ORIRNTATION:", azimuth+", "+pitch+", "+roll);
		      }
		}
	}

	public void getOrientaion(float[] aValues, float[] mValues) {
		float[] R = new float[16];
        float[] orientationValues = new float[3];

        if( aValues == null || mValues == null )
            return;

        if( !SensorManager.getRotationMatrix (R, null, aValues, mValues) )
            return;

        float[] outR = new float[16];
        SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_Z, SensorManager.AXIS_MINUS_X, outR);

        SensorManager.getOrientation (outR, orientationValues);

        orientationValues[0] = (float)Math.toDegrees (orientationValues[0]);
        orientationValues[1] = (float)Math.toDegrees (orientationValues[1]); 
        orientationValues[2] = (float)Math.toDegrees (orientationValues[2]);
        
        Log.i("LORIENTATION: ", orientationValues[0]+", "+orientationValues[1]+", "+orientationValues[2]);
	}
	
	float comp_filter(float newAngle, float newRate) {
		float filterTerm0;
		float filterTerm1;
		float filterTerm2 = 0;
		float timeConstant;

		timeConstant = (float) 0.5; // default 1.0

		filterTerm0 = (newAngle - filterAngle) * timeConstant * timeConstant;
		filterTerm2 += filterTerm0 * dt;
		filterTerm1 = filterTerm2
				+ ((newAngle - filterAngle) * 2 * timeConstant) + newRate;
		filterAngle = (filterTerm1 * dt) + filterAngle;

		return previousAngle; // This is actually the current angle, but is
		// stored for the next iteration
	}

	/**
	 * Determines whether one Location reading is better than the current
	 * Location fix
	 * 
	 * @param location
	 *            The new Location that you want to evaluate
	 * @param currentBestLocation
	 *            The current Location fix, to which you want to compare the new
	 *            one
	 */
	protected Location isBetterLocation(Location location,
			Location currentBestLocation) {
		if (currentBestLocation == null) {
			// A new location is always better than no location
			return currentBestLocation;
		}

		// Check whether the new location fix is newer or older
		long timeDelta = location.getTime() - currentBestLocation.getTime();
		boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
		boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
		boolean isNewer = timeDelta > 0;

		// If it's been more than two minutes since the current location, use
		// the new location
		// because the user has likely moved
		if (isSignificantlyNewer) {
			return currentBestLocation;
			// If the new location is more than two minutes older, it must be
			// worse
		} else if (isSignificantlyOlder) {
			return location;
		}

		// Check whether the new location fix is more or less accurate
		int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation
				.getAccuracy());
		boolean isLessAccurate = accuracyDelta > 0;
		boolean isMoreAccurate = accuracyDelta < 0;
		boolean isSignificantlyLessAccurate = accuracyDelta > 200;

		// Check if the old and new location are from the same provider
		boolean isFromSameProvider = isSameProvider(location.getProvider(),
				currentBestLocation.getProvider());

		// Determine location quality using a combination of timeliness and
		// accuracy
		if (isMoreAccurate) {
			return currentBestLocation;
		} else if (isNewer && !isLessAccurate) {
			return currentBestLocation;
		} else if (isNewer && !isSignificantlyLessAccurate
				&& isFromSameProvider) {
			return currentBestLocation;
		}
		return location;
	}

	/** Checks whether two providers are the same */
	private boolean isSameProvider(String provider1, String provider2) {
		if (provider1 == null) {
			return provider2 == null;
		}
		return provider1.equals(provider2);
	}

	private void CameraControl(int command) {
		switch (command) {
		case 100:
			/**
			 * Command to start taking of photos
			 */
			if (timer == null) {
				timer = new Timer();
			}
			timer.scheduleAtFixedRate(new CameraTask(), 2 * 1000,
					Utils.TIME_IN_SECONDS * 1000);
			isRunning = true;
			break;
		case 110:
			/**
			 * Command to stop taking of photos
			 */
			timer.cancel();
			timer = null;
			isRunning = false;
			break;
		default:
			break;
		}
	}

	/**
	 * Method for taking photos
	 */
	private void takePhoto() {
		myHandler.post(mMyRunnable);
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				text.setText(text.getText() + "\nWaiting: ");
			}
		});
	}

	private Runnable mMyRunnable = new Runnable() {
		private double longitude = 0, latitude = 0, altitude = 0, speed = 0;

		public void run() {
			Camera.Parameters params = camera.getParameters();
			params.set("rotation", 90);

			Location _loc = onGetLocation();
			if (_loc != null) {
				longitude = _loc.getLongitude();
				latitude = _loc.getLatitude();
				altitude = _loc.getAltitude();
				speed = _loc.getSpeed();
				
				params.setGpsAltitude(_loc.getAltitude());
				params.setGpsLatitude(_loc.getLatitude());
				params.setGpsLongitude(_loc.getLongitude());
				params.setGpsTimestamp(_loc.getTime());
				
			}
			camera.setParameters(params);
			camera.takePicture(myShutterCallback, myPictureCallback_RAW,
					myPictureCallback_JPG);
			storePicture(mergeBitmap);

			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					String gyro = "\nPhoto "+COUNTER+": " +
							"Orientation{x:"+OUT2[0]+", y:"+OUT2[1]+", z:"+OUT2[2]+"}, " +
							"Loc{lat:"+latitude+", lon:"+longitude+", alt: "+altitude+", spd:"+speed+"} ";
					Log.i(TAG, "Photo: " + COUNTER+ ": "+gyro + " \n Captured: ");
					text.setText(text.getText() + gyro
							+ " \n Captured: ");
					/**
					 * Save the image parameters
					 */
					String image_name = pictureName + EXTENTION;
					try {
						dhelper.insertImageParameters(image_name, latitude, longitude, altitude, speed,
								OUT2[0], OUT2[1], OUT2[2]);
						
						/**
						 * Start upload of the image
						 */
						uploadImage(image_name, imageFilePath);

					}catch(Exception ex) {
						ex.printStackTrace();
					}
				}
			});
		}
	};
	
	private AsyncTask<Void, Void, Void> mUpload;
	private String image;
	private String path;

	/**
	 * Upload image to the server {image, path}
	 */
	private void uploadImage(String...values){
		image = values.length >= 1?values[0]:null;
		path = values.length >= 2?values[1]:null;


		if (image != null){ 
			mUpload = new AsyncTask<Void, Void, Void>() {
				boolean done = false;

				@Override
				protected Void doInBackground(Void... params) {
					try {
						ArrayList<String> data = dhelper.queueImageParameterString(image);
						genKml();						
						
						String str = "";
						for (String par : data)
							str += par + ", ";
						Log.i(TAG, str);
						
						done = imageUpload(image, path, data);
					}catch(Exception ex){
						ex.printStackTrace();
						done = false;
					}
					return null;
				}

				@Override
				protected void onPostExecute(Void result) {
					/**
					 * Upload is complete 
					 */
					mUpload = null;
					/**
					 * Check if its complete
					 */
					if(done){
						/**
						 * Set upload status to true 
						 */
						Toast.makeText(getApplicationContext(), "Photo uploaded!", 0).show();
						dhelper.setImageUploded(image);
					}else {
						/**
						 * Upload of photo failed.
						 */
						Toast.makeText(getApplicationContext(), "Photo upload failed!", 0).show();
					}
				}	
			};
			mUpload.execute(null, null, null);
		}
	}

	private boolean imageUpload(Object...values){
		String image_ = values.length > 0?values[0].toString():null;
		String path_ = values.length > 1?values[1].toString():null;
		ArrayList<String> data = (ArrayList<String>) (values.length > 2?values[2]:null);

		HttpEntity resEntity;    
		String serverUrl = "";
		serverUrl = SERVER_URL + "/byfileupload.php";
		try {
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(serverUrl);			
			MultipartEntity entity = new MultipartEntity();

			// sending a String param;
			entity.addPart("imgname", new StringBody(image_)); 
			entity.addPart("lat", new StringBody(data.get(0))); 
			entity.addPart("lon", new StringBody(data.get(1))); 
			entity.addPart("alt", new StringBody(data.get(2))); 
			entity.addPart("spd", new StringBody(data.get(3))); 
			entity.addPart("sx", new StringBody(data.get(4))); 
			entity.addPart("sy", new StringBody(data.get(5))); 
			entity.addPart("sz", new StringBody(data.get(6))); 

			if (!path_.equals("")) {
				Log.e("Uploading:", "...."+path);
				File bit = new File(path);
				FileBody bitmaps = new FileBody(bit);
				entity.addPart("image", bitmaps);
			}
			
			post.setEntity(entity);
			HttpResponse response = client.execute(post);
			resEntity = response.getEntity();
			String response_str = EntityUtils.toString(resEntity);
			
			//Log.e(TAG, ".....|>"+response_str);
			
			if (resEntity != null) {
				Log.e(TAG, "RESPONSE: "+response_str);
				/**
				 * We need to tell the database that the image has been uploaded
				 */				
				if (response_str.startsWith("ok")) {
					Log.i(TAG, "Image: "+image+" uploaded");
					return true;
				}
				else if (response_str.startsWith("no")) {
					Log.i(TAG, "Image: "+image+" Not uploaded");
					return false;
				}
			}else {
				Log.i(TAG, "RESPONSE: NONE");
			}
		} catch (Exception ex) {
			Log.e("Debug", "error: " + ex.getMessage(), ex);
			return false;
		}
		return false;
	}

	/**
	 * Get the current location settings
	 * 
	 * @return location An instance of {@link Location}
	 */
	private Location getLocation() {
		/*Log.i(TAG, "Current location");*/
		/**
		 * New location
		 */
		Location location;
		/** Get the last known location using the network provider */
		location = locManager
				.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
		/*if (location != null)
		{*/
		/*Log.i(TAG, location.getLatitude() + ", NETWORK PROVIDER");*/

		/** Get the last known location using the gps provider */
		location = locManager
				.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		/*if (location != null)*/
		/*Log.i(TAG, location.getLatitude() + ", GPS PROVIDER");*/
		return location;
	}

	ShutterCallback myShutterCallback = new ShutterCallback() {

		public void onShutter() {
			// TODO Auto-generated method stub

		}
	};

	PictureCallback myPictureCallback_RAW = new PictureCallback() {

		public void onPictureTaken(byte[] raw, Camera arg1) {
			// TODO Auto-generated method stub

		}
	};

	PictureCallback myPictureCallback_JPG = new PictureCallback() {

		public void onPictureTaken(byte[] arg0, Camera arg1) {
			// TODO Auto-generated method stub

			Display display = getWindowManager().getDefaultDisplay();
			final int ScreenWidth = display.getWidth();
			final int ScreenHeight = display.getHeight();
			Bitmap bitmapPicture = BitmapFactory.decodeByteArray(arg0, 0,
					arg0.length);
			Bitmap bmpScaled1 = Bitmap.createScaledBitmap(bitmapPicture,
					ScreenWidth, ScreenHeight, true);

			mergeBitmap = bmpScaled1;

			showPicture();

		}
	};

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		if (previewing) {
			camera.stopPreview();
			previewing = false;
		}

		if (camera != null) {
			try {
				camera.setPreviewDisplay(surfaceHolder);
				camera.startPreview();
				previewing = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void surfaceCreated(SurfaceHolder holder) {
		camera = Camera.open();
		try {
			camera.setDisplayOrientation(90);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub

		camera.stopPreview();
		camera.release();
		camera = null;
		previewing = false;
	}

	void storePicture(Bitmap bm) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
		String date = dateFormat.format(new Date());		
		this.pictureName = date;
		picNameToshare = this.pictureName;
		this.imageFilePath = IMAGE_FOLDER + this.pictureName + EXTENTION;
		this.imageFilePath = sanitizePath(this.imageFilePath);

		try {
			checkSDCard(this.imageFilePath);

			fos = new FileOutputStream(this.imageFilePath);

			if (fos != null) {
				bm.compress(Bitmap.CompressFormat.JPEG, 85, fos);
				Toast.makeText(this, "Image Saved", Toast.LENGTH_SHORT).show();
				newImage(this.pictureName + EXTENTION, imageFilePath);

				fos.close();
			}
			
			sendBroadcast(new Intent(
					Intent.ACTION_MEDIA_MOUNTED,
					Uri.parse("file://" + Environment.getExternalStorageDirectory())));
			imageFilePath1 = this.imageFilePath;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Check the SDCard is mounted on device
	 * 
	 * @param path
	 *            of image file
	 * @throws IOException
	 */
	void checkSDCard(String path) throws IOException {
		String state = android.os.Environment.getExternalStorageState();
		if (!state.equals(android.os.Environment.MEDIA_MOUNTED)) {

			Toast.makeText(this,
					"Please insert sdcard other wise image won't stored",
					Toast.LENGTH_SHORT).show();
			throw new IOException("SD Card is not mounted.  It is " + state
					+ ".");
		}

		// make sure the directory we plan to store the recording is exists
		File directory = new File(path).getParentFile();

		if (!directory.exists() && !directory.mkdirs()) {

			throw new IOException("Path to file could not be created.");
		}
	}

	private String sanitizePath(String path) {
		if (!path.startsWith("/")) {
			path = "/" + path;
		}

		return Environment.getExternalStorageDirectory().getAbsolutePath()
				+ path;
	}

	void showPicture() {

	}

	/**
	 * A timer task run to take photos after the defined period of time.
	 * 
	 * @author kelvin
	 * 
	 */
	class CameraTask extends TimerTask {

		@Override
		public void run() {
			/**
			 * Called each time after the delay passed to the timer
			 */
			COUNTER++;
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					Toast.makeText(getBaseContext(), "Photo: " + COUNTER, 0)
					.show();

					if (COUNTER == 4) {
						/** Refresh the camera, obtain a fresh instance */
						camera.release();
						Resume();
					} else if (COUNTER > 4 && COUNTER % 2 == 0) {
						/** Refresh the camera, obtain a fresh instance */
						camera.release();
						Resume();
					}
				}
			});
			takePhoto();
		}
	}

}